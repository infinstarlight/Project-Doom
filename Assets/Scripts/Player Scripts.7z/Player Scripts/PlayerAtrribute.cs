﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAtrribute : MonoBehaviour
{

	public float HealthPoints = 100;
	public float StaminaPoints = 100;
    public float attackDamage = 10;
	public int Defense = 5;

	public PlayerAtrribute playerAttr;


	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}
}
